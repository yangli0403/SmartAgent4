from __future__ import annotations

import json
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List

ROOT = Path('/home/ubuntu/work/SmartAgent4')
OUT = ROOT / 'reports' / 'router_capability_0413'
OUT.mkdir(parents=True, exist_ok=True)
random.seed(42)

RETRIEVAL_FILE = ROOT / 'reports' / 'training_data_0413' / 'retrieval_gate_train.jsonl'


def load_jsonl(path: Path) -> List[dict]:
    rows = []
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def dump_jsonl(path: Path, rows: List[dict]) -> None:
    with path.open('w', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')


DOMAIN_TO_AGENTS = {
    'general': ['generalAgent'],
    'navigation': ['navigationAgent'],
    'file_system': ['fileAgent'],
    'multimedia': ['multimediaAgent'],
}


def infer_router_labels(text: str, decision: str) -> dict:
    t = text.strip()
    lower = t.lower()
    if t == '':
        return {
            'domain': 'general',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['generalAgent'],
        }

    if any(k in t for k in ['天气', '路线', '导航', '附近', '充电桩', '餐厅', '回家']) or 'weather' in lower:
        domain = 'navigation'
    elif any(k in t for k in ['文件', '目录', 'c盘', 'C盘', '磁盘', '桌面', '下载']) or 'pdf' in lower or 'ppt' in lower:
        domain = 'file_system'
    elif any(k in t for k in ['音乐', '歌曲', '歌单', '播放', '周杰伦', '歌手']) or 'song' in lower:
        domain = 'multimedia'
    else:
        domain = 'general'

    complexity = 'simple'
    planner_gate = 'DIRECT'
    if any(k in t for k in ['并', '然后', '再', '顺路']) or any(k in t for k in ['最新', '最大', '最近', '昨天下载']):
        complexity = 'moderate'
        planner_gate = 'PLAN'
    if sum(k in t for k in ['然后', '并', '顺路']) >= 2:
        complexity = 'complex'
        planner_gate = 'PLAN'

    if decision == 'UNCERTAIN':
        memory_gate = 'UNCERTAIN'
    else:
        memory_gate = decision

    return {
        'domain': domain,
        'complexity': complexity,
        'memory_gate': memory_gate,
        'planner_gate': planner_gate,
        'required_agents': DOMAIN_TO_AGENTS.get(domain, ['generalAgent']),
    }


pre_router_seed_manual = [
    {
        'input': '帮我分析一下下载目录的文件占比',
        'output': {
            'domain': 'file_system',
            'complexity': 'moderate',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'PLAN',
            'required_agents': ['fileAgent'],
        },
        'source': 'manual_bootstrap_from_classify_tests',
        'label_quality': 'manual',
    },
    {
        'input': '帮我分析一下我C盘的情况',
        'output': {
            'domain': 'file_system',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['fileAgent'],
        },
        'source': 'manual_bootstrap_from_classify_tests',
        'label_quality': 'manual',
    },
    {
        'input': '看看C盘空间',
        'output': {
            'domain': 'file_system',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['fileAgent'],
        },
        'source': 'manual_bootstrap_from_classify_tests',
        'label_quality': 'manual',
    },
    {
        'input': '公司在：太湖软件园；家在：苏州工业园区九龙仓。帮我规划回家路线。',
        'output': {
            'domain': 'navigation',
            'complexity': 'moderate',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'PLAN',
            'required_agents': ['navigationAgent'],
        },
        'source': 'manual_bootstrap_from_dialogue_slots',
        'label_quality': 'manual',
    },
    {
        'input': '帮我找一下昨天下载的ppt文件并打开修改时间最新的一个',
        'output': {
            'domain': 'file_system',
            'complexity': 'moderate',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'PLAN',
            'required_agents': ['fileAgent'],
        },
        'source': 'manual_bootstrap_from_plan_execute_tests',
        'label_quality': 'manual',
    },
    {
        'input': '帮我找一下桌面上的所有PDF文件，打开最大的那个，然后用Chrome打开',
        'output': {
            'domain': 'cross_domain',
            'complexity': 'complex',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'PLAN',
            'required_agents': ['fileAgent', 'generalAgent'],
        },
        'source': 'manual_bootstrap_from_plan_execute_tests',
        'label_quality': 'manual',
    },
    {
        'input': '查天气然后创建文件记录',
        'output': {
            'domain': 'cross_domain',
            'complexity': 'complex',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'PLAN',
            'required_agents': ['navigationAgent', 'fileAgent'],
        },
        'source': 'manual_bootstrap_cross_domain',
        'label_quality': 'manual',
    },
    {
        'input': '搜索附近餐厅并导航到最近的',
        'output': {
            'domain': 'navigation',
            'complexity': 'moderate',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'PLAN',
            'required_agents': ['navigationAgent'],
        },
        'source': 'manual_bootstrap_from_prompt_rules',
        'label_quality': 'manual',
    },
    {
        'input': '播放周杰伦的歌',
        'output': {
            'domain': 'multimedia',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['multimediaAgent'],
        },
        'source': 'manual_bootstrap_from_agent_cards',
        'label_quality': 'manual',
    },
    {
        'input': '找一首适合开车听的歌',
        'output': {
            'domain': 'multimedia',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['multimediaAgent'],
        },
        'source': 'manual_bootstrap_from_agent_cards',
        'label_quality': 'manual',
    },
    {
        'input': '给我今日音乐推荐',
        'output': {
            'domain': 'multimedia',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['multimediaAgent'],
        },
        'source': 'manual_bootstrap_from_agent_cards',
        'label_quality': 'manual',
    },
    {
        'input': '帮我写一段Python代码',
        'output': {
            'domain': 'general',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['generalAgent'],
        },
        'source': 'manual_bootstrap_general',
        'label_quality': 'manual',
    },
    {
        'input': '总结一下这段日志的主要问题',
        'output': {
            'domain': 'general',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['generalAgent'],
        },
        'source': 'manual_bootstrap_general',
        'label_quality': 'manual',
    },
    {
        'input': '推荐一部适合我的电影',
        'output': {
            'domain': 'general',
            'complexity': 'simple',
            'memory_gate': 'RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['generalAgent'],
        },
        'source': 'manual_bootstrap_personalized_general',
        'label_quality': 'manual',
    },
    {
        'input': '我现在在哪个城市',
        'output': {
            'domain': 'navigation',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['navigationAgent'],
        },
        'source': 'manual_bootstrap_navigation',
        'label_quality': 'manual',
    },
    {
        'input': '附近有什么便宜的充电桩',
        'output': {
            'domain': 'navigation',
            'complexity': 'simple',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'DIRECT',
            'required_agents': ['navigationAgent'],
        },
        'source': 'manual_bootstrap_navigation',
        'label_quality': 'manual',
    },
    {
        'input': '把搜索到的充电桩结果保存到桌面文件',
        'output': {
            'domain': 'cross_domain',
            'complexity': 'complex',
            'memory_gate': 'NO_RETRIEVE',
            'planner_gate': 'PLAN',
            'required_agents': ['navigationAgent', 'fileAgent'],
        },
        'source': 'manual_bootstrap_cross_domain',
        'label_quality': 'manual',
    },
]


def build_pre_router_dataset() -> Dict[str, List[dict]]:
    retrieval_rows = load_jsonl(RETRIEVAL_FILE)
    rows: List[dict] = []
    for item in retrieval_rows:
        inp = item.get('input', '')
        decision = item.get('output', {}).get('decision', 'UNCERTAIN')
        labels = infer_router_labels(inp, decision)
        rows.append({
            'input': inp,
            'output': labels,
            'source': item.get('source_file', 'unknown'),
            'source_case': item.get('source_case', ''),
            'label_quality': 'gold' if decision in {'RETRIEVE', 'NO_RETRIEVE'} else 'heuristic',
        })
    rows.extend(pre_router_seed_manual)

    seen = set()
    deduped = []
    for row in rows:
        key = (row['input'], json.dumps(row['output'], ensure_ascii=False, sort_keys=True))
        if key not in seen:
            seen.add(key)
            deduped.append(row)

    by_domain = defaultdict(list)
    for row in deduped:
        by_domain[row['output']['domain']].append(row)

    train, test = [], []
    for domain, items in by_domain.items():
        random.shuffle(items)
        test_size = max(1, round(len(items) * 0.2))
        test.extend(items[:test_size])
        train.extend(items[test_size:])

    train = sorted(train, key=lambda x: (x['output']['domain'], x['input']))
    test = sorted(test, key=lambda x: (x['output']['domain'], x['input']))
    all_rows = train + test
    return {'all': all_rows, 'train': train, 'test': test}


CAPABILITY_SPECS = {
    'file_search': {
        'domain': 'file_system', 'agent': 'fileAgent',
        'description': '按名称、时间、类型、位置等条件搜索文件。',
        'tools': ['search_files'],
        'queries': ['帮我找昨天下载的ppt文件', '搜索桌面上的所有PDF文件', '在下载目录里找最新的照片'],
    },
    'file_management': {
        'domain': 'file_system', 'agent': 'fileAgent',
        'description': '打开文件、查看文件信息、复制文件等文件级管理动作。',
        'tools': ['open_file', 'get_file_info', 'copy_files'],
        'queries': ['打开最大的那个PDF', '查看这个文件的详细信息', '把这个文件复制到备份目录'],
    },
    'directory_operations': {
        'domain': 'file_system', 'agent': 'fileAgent',
        'description': '列目录、创建目录、分析目录结构与占比。',
        'tools': ['list_directory', 'create_folder', 'analyze_directory'],
        'queries': ['列出下载目录里的内容', '创建一个新的备份文件夹', '分析一下下载目录的文件占比'],
    },
    'app_launch': {
        'domain': 'file_system', 'agent': 'fileAgent',
        'description': '启动或关闭本地应用程序。',
        'tools': ['launch_app', 'close_app', 'list_running_apps'],
        'queries': ['帮我打开Chrome', '启动记事本', '关闭当前正在运行的微信'],
    },
    'browser_control': {
        'domain': 'file_system', 'agent': 'fileAgent',
        'description': '通过系统能力直接拉起或控制浏览器页面。',
        'tools': ['browser_control'],
        'queries': ['用Chrome打开这个网页', '在浏览器里打开GitHub', '帮我用Chrome访问百度'],
    },
    'file_organization': {
        'domain': 'file_system', 'agent': 'fileAgent',
        'description': '批量移动、删除、归档文件，实现目录整理。',
        'tools': ['move_files', 'delete_files', 'create_folder'],
        'queries': ['把下载目录里的zip整理到备份文件夹', '删除这些临时文件', '把照片移动到图片目录'],
    },
    'duplicate_detection': {
        'domain': 'file_system', 'agent': 'fileAgent',
        'description': '检测重复文件并给出重复项清单。',
        'tools': ['find_duplicates'],
        'queries': ['找出下载目录里的重复文件', '看看哪些照片重复了', '帮我检测一下重复文档'],
    },
    'general_conversation': {
        'domain': 'general', 'agent': 'generalAgent',
        'description': '普通寒暄、闲聊和泛对话响应。',
        'tools': [],
        'queries': ['你好呀', '陪我聊聊天', '最近怎么样'],
    },
    'knowledge_qa': {
        'domain': 'general', 'agent': 'generalAgent',
        'description': '面向公开知识的问答与解释。',
        'tools': [],
        'queries': ['什么是量子计算', '解释一下TCP三次握手', '黑洞是怎么形成的'],
    },
    'information_analysis': {
        'domain': 'general', 'agent': 'generalAgent',
        'description': '对文本、日志、方案或数据进行分析判断。',
        'tools': [],
        'queries': ['帮我分析这段日志', '比较一下这两份方案的优缺点', '分析一下这份需求文档的风险'],
    },
    'result_summarization': {
        'domain': 'general', 'agent': 'generalAgent',
        'description': '对已有内容进行总结、压缩和归纳。',
        'tools': [],
        'queries': ['把上面的内容总结成三点', '帮我汇总一下搜索结果', '整理一个简短结论'],
    },
    'memory_management': {
        'domain': 'general', 'agent': 'generalAgent',
        'description': '用户画像记忆的新增、查询、更新与删除。',
        'tools': ['memory_store', 'memory_search', 'memory_update', 'memory_forget'],
        'queries': ['记住我喜欢吃川菜', '你还记得我叫什么吗', '把我之前的住址更新一下'],
    },
    'music_search': {
        'domain': 'multimedia', 'agent': 'multimediaAgent',
        'description': '搜索歌曲、歌手、专辑等音乐内容。',
        'tools': ['search', 'get_song_detail', 'get_artist'],
        'queries': ['搜一下周杰伦的歌', '找一首适合开车听的音乐', '搜索告五人的新歌'],
    },
    'music_playback': {
        'domain': 'multimedia', 'agent': 'multimediaAgent',
        'description': '播放指定歌曲或继续播放。',
        'tools': ['get_song_url', 'get_unblocked_url'],
        'queries': ['播放晴天', '放一首轻音乐', '继续播放上一首'],
    },
    'playlist_management': {
        'domain': 'multimedia', 'agent': 'multimediaAgent',
        'description': '查看或操作用户歌单。',
        'tools': ['get_playlist'],
        'queries': ['打开我的收藏歌单', '查看周杰伦歌单', '帮我找我的私人歌单'],
    },
    'daily_recommendation': {
        'domain': 'multimedia', 'agent': 'multimediaAgent',
        'description': '获取每日推荐歌曲或推荐列表。',
        'tools': ['get_playlist'],
        'queries': ['给我今日音乐推荐', '看看今天的每日推荐', '今天推荐我听什么歌'],
    },
    'poi_search': {
        'domain': 'navigation', 'agent': 'navigationAgent',
        'description': '搜索周边POI、地点详情与筛选结果。',
        'tools': ['maps_around_search', 'maps_text_search', 'maps_search_detail'],
        'queries': ['附近有什么便宜的充电桩', '搜一下附近的川菜馆', '查找最近的加油站'],
    },
    'route_planning': {
        'domain': 'navigation', 'agent': 'navigationAgent',
        'description': '计算从起点到终点的路线或带途经点的路径。',
        'tools': ['maps_direction_driving', 'maps_direction_walking', 'maps_direction_transit_integrated'],
        'queries': ['帮我规划回家路线', '从公司到机场怎么走', '规划去山姆再回家的路线'],
    },
    'geocoding': {
        'domain': 'navigation', 'agent': 'navigationAgent',
        'description': '地址与经纬度之间的转换和定位。',
        'tools': ['maps_geo', 'maps_regeocode', 'free_geocode_city'],
        'queries': ['把这个地址转成经纬度', '苏州工业园区在哪里', '查询北京朝阳区的坐标'],
    },
    'weather_query': {
        'domain': 'navigation', 'agent': 'navigationAgent',
        'description': '按城市或坐标查询天气与预报。',
        'tools': ['maps_weather', 'free_weather_by_city', 'free_weather_by_coords'],
        'queries': ['明天北京天气怎么样', '查一下上海今天会不会下雨', '苏州这周天气如何'],
    },
    'ip_location': {
        'domain': 'navigation', 'agent': 'navigationAgent',
        'description': '根据当前IP或设备上下文估计所在城市。',
        'tools': ['maps_ip_location', 'free_ip_location'],
        'queries': ['我现在在哪个城市', '查一下当前IP定位', '看看我当前位置在哪'],
    },
    'navigation': {
        'domain': 'navigation', 'agent': 'navigationAgent',
        'description': '直接发起导航动作或跳转到导航应用。',
        'tools': ['maps_schema_navi', 'maps_schema_take_taxi', 'maps_schema_personal_map'],
        'queries': ['导航到最近的山姆', '开始导航去公司', '带我去苏州站'],
    },
}


def build_capability_dataset() -> Dict[str, List[dict]]:
    corpus = []
    triplets_all = []
    rerank_all = []

    by_domain = defaultdict(list)
    for cap, spec in CAPABILITY_SPECS.items():
        by_domain[spec['domain']].append(cap)

    for cap, spec in CAPABILITY_SPECS.items():
        aliases = [cap, cap.replace('_', ' '), spec['description']]
        corpus.append({
            'capability': cap,
            'domain': spec['domain'],
            'agent': spec['agent'],
            'tools': spec['tools'],
            'aliases': aliases,
            'text': f"capability={cap}; domain={spec['domain']}; agent={spec['agent']}; description={spec['description']}; tools={', '.join(spec['tools']) if spec['tools'] else 'none'}",
        })

        negatives = [c for c in by_domain[spec['domain']] if c != cap]
        cross_negatives = [c for c in CAPABILITY_SPECS if CAPABILITY_SPECS[c]['domain'] != spec['domain']]

        for idx, query in enumerate(spec['queries']):
            chosen_negatives = negatives[:2] + cross_negatives[:1]
            triplets_all.append({
                'query': query,
                'positive_capability': cap,
                'negative_capabilities': chosen_negatives,
                'domain': spec['domain'],
                'agent': spec['agent'],
                'source': 'manual_capability_bootstrap',
                'label_quality': 'manual',
            })
            rerank_all.append({
                'query': query,
                'candidate_capability': cap,
                'candidate_text': corpus[-1]['text'],
                'label': 1,
                'domain': spec['domain'],
            })
            for neg in chosen_negatives:
                neg_spec = CAPABILITY_SPECS[neg]
                rerank_all.append({
                    'query': query,
                    'candidate_capability': neg,
                    'candidate_text': f"capability={neg}; domain={neg_spec['domain']}; agent={neg_spec['agent']}; description={neg_spec['description']}; tools={', '.join(neg_spec['tools']) if neg_spec['tools'] else 'none'}",
                    'label': 0,
                    'domain': spec['domain'],
                })

    train_triplets, test_triplets = [], []
    train_rerank, test_rerank = [], []
    grouped_triplets = defaultdict(list)
    grouped_rerank = defaultdict(list)

    for row in triplets_all:
        grouped_triplets[row['positive_capability']].append(row)
    for row in rerank_all:
        grouped_rerank[row['query']].append(row)

    for cap, items in grouped_triplets.items():
        random.shuffle(items)
        test_triplets.append(items[0])
        train_triplets.extend(items[1:])

    test_queries = {row['query'] for row in test_triplets}
    for query, items in grouped_rerank.items():
        if query in test_queries:
            test_rerank.extend(items)
        else:
            train_rerank.extend(items)

    return {
        'corpus': corpus,
        'triplet_train': sorted(train_triplets, key=lambda x: (x['domain'], x['positive_capability'], x['query'])),
        'triplet_test': sorted(test_triplets, key=lambda x: (x['domain'], x['positive_capability'], x['query'])),
        'rerank_train': sorted(train_rerank, key=lambda x: (x['domain'], x['query'], -x['label'], x['candidate_capability'])),
        'rerank_test': sorted(test_rerank, key=lambda x: (x['domain'], x['query'], -x['label'], x['candidate_capability'])),
    }


pre_router = build_pre_router_dataset()
capability = build_capability_dataset()

# Write raw data files
pre_router_dir = OUT / 'pre_router'
capability_dir = OUT / 'capability'
pre_router_dir.mkdir(parents=True, exist_ok=True)
capability_dir.mkdir(parents=True, exist_ok=True)

dump_jsonl(pre_router_dir / 'pre_router_seed_all.jsonl', pre_router['all'])
dump_jsonl(pre_router_dir / 'pre_router_train.jsonl', pre_router['train'])
dump_jsonl(pre_router_dir / 'pre_router_test.jsonl', pre_router['test'])
dump_jsonl(capability_dir / 'capability_corpus.jsonl', capability['corpus'])
dump_jsonl(capability_dir / 'capability_triplet_train.jsonl', capability['triplet_train'])
dump_jsonl(capability_dir / 'capability_triplet_test.jsonl', capability['triplet_test'])
dump_jsonl(capability_dir / 'capability_rerank_train.jsonl', capability['rerank_train'])
dump_jsonl(capability_dir / 'capability_rerank_test.jsonl', capability['rerank_test'])


# Summaries
pre_train_domain = Counter(r['output']['domain'] for r in pre_router['train'])
pre_test_domain = Counter(r['output']['domain'] for r in pre_router['test'])
pre_memory = Counter(r['output']['memory_gate'] for r in pre_router['all'])
cap_train_domain = Counter(r['domain'] for r in capability['triplet_train'])
cap_test_domain = Counter(r['domain'] for r in capability['triplet_test'])

summary = {
    'pre_router': {
        'all_count': len(pre_router['all']),
        'train_count': len(pre_router['train']),
        'test_count': len(pre_router['test']),
        'train_domain_distribution': dict(pre_train_domain),
        'test_domain_distribution': dict(pre_test_domain),
        'memory_gate_distribution': dict(pre_memory),
    },
    'capability': {
        'capability_count': len(capability['corpus']),
        'triplet_train_count': len(capability['triplet_train']),
        'triplet_test_count': len(capability['triplet_test']),
        'rerank_train_count': len(capability['rerank_train']),
        'rerank_test_count': len(capability['rerank_test']),
        'triplet_train_domain_distribution': dict(cap_train_domain),
        'triplet_test_domain_distribution': dict(cap_test_domain),
    },
}
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def md_rows(counter: Counter) -> str:
    return ''.join(f"| {k} | {v} |\n" for k, v in sorted(counter.items()))


pre_train_domain_rows = md_rows(pre_train_domain)
pre_test_domain_rows = md_rows(pre_test_domain)
pre_memory_rows = md_rows(pre_memory)
cap_train_domain_rows = md_rows(cap_train_domain)
cap_test_domain_rows = md_rows(cap_test_domain)


scheme_md = f'''# Pre-Router 与 Capability 技术方案（0413）

本文将 **Pre-Router** 与 **Capability** 作为两类不同的问题来设计。前者解决的是**粗粒度路由与门控**，后者解决的是**细粒度能力召回**。两者都要求输出结构化结果，但**结构化输出不是单独业务层**，而是两者共同遵守的工程约束。

| 模块 | 推荐主方案 | 参数规模 | 开源仓库 | 推荐原因 |
|---|---|---:|---|---|
| **Pre-Router** | **Qwen3-1.7B-Instruct** 微调版 | **1.7B** | [Qwen3](https://github.com/QwenLM/qwen3) | 中文指令理解强，足够轻量，可直接做 JSON schema 输出 |
| **Capability** | **Qwen3-Embedding-0.6B + Qwen3-Reranker-0.6B** | **0.6B + 0.6B** | [Qwen3-Embedding](https://github.com/QwenLM/Qwen3-Embedding) | 更适合能力标签扩展场景，避免每次新增 capability 都重新训练分类器 |
| **Capability 备选** | **BGE 系列 Embedding + Reranker** | 多档可选 | [FlagEmbedding](https://github.com/FlagOpen/FlagEmbedding) | 生态成熟，便于做中文检索基线 |

## 一、Pre-Router 的推荐方案

Pre-Router 不建议只做单一领域分类，而建议做成一个**多头轻量路由器**。其输出 schema 应统一为 `domain / complexity / memory_gate / planner_gate / required_agents`。这样设计的原因是：在系统真正进入 Capability 和 Planner 之前，先完成粗分流、复杂度估计以及“是否要先检索记忆”的前置判断，可以显著降低后续链路的不确定性。

| 字段 | 标签空间 | 用途 |
|---|---|---|
| `domain` | `general / file_system / navigation / multimedia / cross_domain` | 决定主链路与候选 Agent 池 |
| `complexity` | `simple / moderate / complex` | 决定是直执行还是进入计划器 |
| `memory_gate` | `RETRIEVE / NO_RETRIEVE / UNCERTAIN` | 决定是否进入记忆检索前置链路 |
| `planner_gate` | `DIRECT / PLAN` | 决定是否触发 Planner |
| `required_agents` | Agent ID 列表 | 为 Capability / Planner 提供候选执行边界 |

> **推荐落地方式**：以 Qwen3-1.7B-Instruct 为底座，采用 LoRA SFT 微调，输入只保留最近一轮用户话语和极少量上下文，输出严格 JSON。部署时可保留现有规则层，形成“规则优先 + 小模型回退”的混合架构。

我不建议把 Pre-Router 做成 embedding 检索，因为它的核心是**固定标签空间下的多头分类**，而不是开放语义空间中的候选召回。对这类任务，轻量 instruct 模型做结构化分类，通常比 embedding 相似度直接阈值判定更稳定。

## 二、Capability 的推荐方案

Capability 不建议直接训练成“闭集分类器”。原因在于当前项目中的 capability 来自 Agent Card，随着 Agent、MCP Server 和工具的扩展，标签空间会持续变化。如果每增加一个 capability 都要重新训练整套分类器，维护成本会快速上升。因此更合适的设计是：

1. 先把每个 capability 编码成统一的**语义卡片**；
2. 用 **Embedding 模型**做 Top-K 召回；
3. 用 **Reranker 模型**在小候选集上做精排；
4. 只在置信度不足时回退到通用 LLM 做结构化 disambiguation。

| 层级 | 推荐模型 | 输出 |
|---|---|---|
| 召回层 | **Qwen3-Embedding-0.6B** | Top-K capability 候选 |
| 精排层 | **Qwen3-Reranker-0.6B** | 排序后的 capability 列表与分数 |
| 兜底层 | Qwen3-1.7B-Instruct | 结构化 disambiguation / abstain |

> **一句话理解**：Pre-Router 是“先分到哪一摊”，Capability 是“这一摊里到底该做哪种动作”。Capability 更像“可扩展的能力检索”，而不是传统固定意图分类。

## 三、参数规模与工程建议

| 模块 | 训练方式 | 推理建议 | 备注 |
|---|---|---|---|
| **Pre-Router** | LoRA SFT | 单条输入、低温度、强 schema 约束 | 可继续复用现有规则层 |
| **Capability-Embedding** | 初期可零训练；后续可用 triplet 微调 | 构建 capability 向量库 | 对新增 Agent / MCP 友好 |
| **Capability-Reranker** | Pair / listwise 微调 | 对 Top-10 候选精排 | 是效果提升的关键 |

当前阶段最稳妥的组合是：**Pre-Router 用 1.7B 小模型分类，Capability 用 0.6B embedding + 0.6B reranker 检索栈。** 这样既能控制延迟，也能给后续 capability 扩容预留空间。
'''
(OUT / 'technical_scheme_0413.md').write_text(scheme_md, encoding='utf-8')

pre_doc = f'''# Pre-Router 训练与测试数据文档（0413）

本文档对应的目标模型是 **Qwen3-1.7B-Instruct LoRA**。这里的 Pre-Router 并不只做单一领域分类，而是做**多头粗路由**：同时产出 `domain / complexity / memory_gate / planner_gate / required_agents`。这样做可以直接兼容当前项目中的分类提示词与 pre-retrieval 决策逻辑。

| 项目 | 内容 |
|---|---|
| **目标任务** | 多头结构化分类 |
| **推荐底模** | Qwen3-1.7B-Instruct |
| **参数规模** | 1.7B |
| **开源仓库** | <https://github.com/QwenLM/qwen3> |
| **训练文件** | `pre_router_train.jsonl` |
| **测试文件** | `pre_router_test.jsonl` |

## 一、标签定义

| 字段 | 标签空间 | 说明 |
|---|---|---|
| `domain` | `general / file_system / navigation / multimedia / cross_domain` | 粗领域 |
| `complexity` | `simple / moderate / complex` | 复杂度 |
| `memory_gate` | `RETRIEVE / NO_RETRIEVE / UNCERTAIN` | 是否先走记忆检索 |
| `planner_gate` | `DIRECT / PLAN` | 是否需要 Planner |
| `required_agents` | Agent ID 列表 | 候选 Agent 边界 |

## 二、数据来源与质量分层

当前数据是一个**可直接开工的种子集**，由两部分组成：其一是现有测试中的真实样本，尤其是 `preRetrievalDecision.test.ts`；其二是根据 `classifyNode`、`planExecuteGraph`、`dialogueSlots` 和 Agent Card 手工补齐的跨域样本。由于项目现阶段公开测试中的领域类金标并不充足，因此文档中显式保留了 `label_quality` 字段，用来区分 `gold / heuristic / manual` 三类样本质量。

| 数据切分 | 数量 |
|---|---:|
| **全量种子样本** | {summary['pre_router']['all_count']} |
| **训练集** | {summary['pre_router']['train_count']} |
| **测试集** | {summary['pre_router']['test_count']} |

## 三、分布统计

### 训练集领域分布

| domain | count |
|---|---:|
{pre_train_domain_rows}

### 测试集领域分布

| domain | count |
|---|---:|
{pre_test_domain_rows}

### 全量 memory_gate 分布

| memory_gate | count |
|---|---:|
{pre_memory_rows}

## 四、训练样本格式

```json
{{
  "input": "帮我找一下昨天下载的ppt文件并打开修改时间最新的一个",
  "output": {{
    "domain": "file_system",
    "complexity": "moderate",
    "memory_gate": "NO_RETRIEVE",
    "planner_gate": "PLAN",
    "required_agents": ["fileAgent"]
  }},
  "source": "manual_bootstrap_from_plan_execute_tests",
  "label_quality": "manual"
}}
```

## 五、使用建议

第一，建议把 `gold` 与 `manual` 样本先用于首轮 SFT，而 `heuristic` 样本在训练中降低权重或只用于 warm-up。第二，线上评测时，不应只看整体准确率，而应拆成 **domain F1、memory_gate F1、planner_gate F1** 三个主指标。第三，当业务日志开始积累后，应优先回填 `cross_domain` 与 `multimedia` 样本，因为这两类在当前测试集中最稀缺。
'''
(pre_router_dir / 'PRE_ROUTER_DATA_DOC_0413.md').write_text(pre_doc, encoding='utf-8')

cap_doc = f'''# Capability 训练与测试数据文档（0413）

本文档对应的目标方案不是单个闭集分类器，而是 **Embedding 召回 + Reranker 精排**。其核心原因在于：Capability 标签来自 Agent Card，是一个会随着 Agent / MCP 扩容而持续增长的集合，因此更适合做**可扩展语义检索**而不是一次性写死的意图分类。

| 项目 | 内容 |
|---|---|
| **目标任务** | 细粒度 capability 召回与精排 |
| **推荐召回模型** | Qwen3-Embedding-0.6B |
| **推荐精排模型** | Qwen3-Reranker-0.6B |
| **参数规模** | 0.6B + 0.6B |
| **开源仓库** | <https://github.com/QwenLM/Qwen3-Embedding> |
| **备选仓库** | <https://github.com/FlagOpen/FlagEmbedding> |
| **训练文件** | `capability_triplet_train.jsonl` 与 `capability_rerank_train.jsonl` |
| **测试文件** | `capability_triplet_test.jsonl` 与 `capability_rerank_test.jsonl` |

## 一、标签空间

当前项目的 Agent Card 中共有 **{summary['capability']['capability_count']}** 个 capability 标签，覆盖 `file_system / general / multimedia / navigation` 四个大域。为了让召回模型工作，每个 capability 都被编码成一条**能力语义卡片**，其中包含 capability 名称、domain、agent、说明和主要 tools。

## 二、数据构成

| 文件 | 用途 | 数量 |
|---|---|---:|
| `capability_corpus.jsonl` | capability 语义库 | {summary['capability']['capability_count']} |
| `capability_triplet_train.jsonl` | Embedding / dual-encoder 训练 | {summary['capability']['triplet_train_count']} |
| `capability_triplet_test.jsonl` | Embedding / dual-encoder 测试 | {summary['capability']['triplet_test_count']} |
| `capability_rerank_train.jsonl` | Reranker 训练 | {summary['capability']['rerank_train_count']} |
| `capability_rerank_test.jsonl` | Reranker 测试 | {summary['capability']['rerank_test_count']} |

## 三、训练集与测试集分布

### Triplet 训练集领域分布

| domain | count |
|---|---:|
{cap_train_domain_rows}

### Triplet 测试集领域分布

| domain | count |
|---|---:|
{cap_test_domain_rows}

## 四、数据格式

### 1. capability 语义库格式

```json
{{
  "capability": "route_planning",
  "domain": "navigation",
  "agent": "navigationAgent",
  "tools": ["maps_direction_driving", "maps_direction_walking"],
  "aliases": ["route_planning", "route planning", "计算从起点到终点的路线或带途经点的路径。"],
  "text": "capability=route_planning; domain=navigation; agent=navigationAgent; description=计算从起点到终点的路线或带途经点的路径。; tools=maps_direction_driving, maps_direction_walking"
}}
```

### 2. triplet 训练格式

```json
{{
  "query": "帮我规划回家路线",
  "positive_capability": "route_planning",
  "negative_capabilities": ["poi_search", "weather_query", "file_search"],
  "domain": "navigation",
  "agent": "navigationAgent",
  "source": "manual_capability_bootstrap",
  "label_quality": "manual"
}}
```

### 3. reranker 训练格式

```json
{{
  "query": "帮我规划回家路线",
  "candidate_capability": "route_planning",
  "candidate_text": "capability=route_planning; domain=navigation; agent=navigationAgent; description=计算从起点到终点的路线或带途经点的路径。; tools=maps_direction_driving, maps_direction_walking, maps_direction_transit_integrated",
  "label": 1,
  "domain": "navigation"
}}
```

## 五、使用建议

第一，Capability 模型应优先评估 **Recall@K、MRR、nDCG**，而不是只看 top-1 准确率。第二，训练时要保留**同域 hard negatives**，因为真实误召回往往发生在同域能力之间，例如 `route_planning` 与 `navigation`、`music_search` 与 `music_playback`。第三，后续当 Agent Card 或 MCP Server 扩充时，应先更新 `capability_corpus.jsonl`，再用新增日志回填 triplet / reranker 数据，而不是直接重训闭集分类器。
'''
(capability_dir / 'CAPABILITY_DATA_DOC_0413.md').write_text(cap_doc, encoding='utf-8')

print(json.dumps(summary, ensure_ascii=False, indent=2))
